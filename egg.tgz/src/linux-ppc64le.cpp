// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("linux ppc64le"); }
int main(){
  announce();
  return lionss_run_workload("linux-ppc64le");
}
