// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("ccache stats\n", stdout);
  return lionss_run_workload("ccache-stats");
}
