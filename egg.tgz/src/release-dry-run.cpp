// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("release dry run\n", stdout);
  return lionss_run_workload("release-dry-run");
}
