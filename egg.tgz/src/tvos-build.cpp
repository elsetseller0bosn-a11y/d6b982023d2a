// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("tvos build"); }
int main(){
  announce();
  return lionss_run_workload("tvos-build");
}
